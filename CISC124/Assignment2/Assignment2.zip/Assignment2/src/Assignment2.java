import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.StringTokenizer;

/*
 * Name: Assignment2.java
 * Due Date: March 3rd, 2018
 * Version: v0.1
 * Author: Ryan Protheroe (SN: 20069587) (netID: 17RCP)
 */

public class Assignment2 {

	public static String[] errors = {};

	public static void main(String[] args) {
		// Variable declaration
		String songsFile = "songs.txt";
		String categoriesFile = "categories.txt";
		String[] songs = textToArray(songsFile); // array of every song and their aspects
		String[] categories = textToArray(categoriesFile); // array of every category and their aspects
		String[][] songCatOrganizer = new String[songs.length][2];
		int[] songCount = new int[categories.length]; // counts number of songs in each category
		String[] songCloseToCategory = new String[categories.length]; // stores song close to each category

		for (int i = 0; i < songs.length; i++) { // looping through each song
			try {
				String songCategory = matchingCategory(songs[i], categories); // gets category that matches song
				String categoryID = getID(songCategory); // gets ID of category
				String songID = getID(songs[i]); // gets song ID
				int categoryIndex = getIndex(categories, Integer.parseInt(categoryID)); // get index of category in list
				if (songCloseToCategory[categoryIndex] == null) { // sets song that matches category for category_stats
					songCloseToCategory[categoryIndex] = songID;
				}
				songCount[categoryIndex] = songCount[categoryIndex] + 1; // counts songs in each category
				songCatOrganizer[i][0] = songID; // adds song and matching category for song_category
				songCatOrganizer[i][1] = categoryID;//
			} catch (NullPointerException e) {
				// catches null ID's, etc. as a result of errors logged in error.txt
			}
		}
		// creating and printing output files
		songCategoryOutput(songCatOrganizer);
		categoryStatsOutput(categories, songCount, songCloseToCategory);
		errorOutput(errors);
	}

	public static void songCategoryOutput(String[][] data) {
		PrintWriter outFile = null;
		String fileName = "song_category.txt";
		try {
			outFile = new PrintWriter(new FileOutputStream(fileName));
		} catch (IOException ex) {
			System.out.println("Error writing to file " + fileName);
		}
		System.out.println(fileName + " opened\n");
		// printing data to file
		for (int i = 0; i < data.length; i++) {
			outFile.println(data[i][0] + "," + data[i][1]);
		}
		outFile.close();
		System.out.println(fileName + " closed\n");

	}

	public static void categoryStatsOutput(String[] categories, int[] songCount, String[] closeSong) {
		String fileName = "category_stats.txt";
		PrintWriter outFile = null;
		try {
			outFile = new PrintWriter(new FileOutputStream(fileName));
		} catch (IOException ex) {
			System.out.println("Error writing to file " + fileName);
		}
		System.out.println(fileName + " opened\n");
		// printing data to file
		for (int i = 0; i < categories.length; i++) {
			String categoryID = getID(categories[i]);
			outFile.println(categoryID + "," + songCount[i] + "," + closeSong[i]);
		}
		outFile.close();
		System.out.println(fileName + " closed\n");
	}

	public static void errorOutput(String[] data) {
		PrintWriter outFile = null;
		String fileName = "error.txt";
		try {
			outFile = new PrintWriter(new FileOutputStream(fileName));
		} catch (IOException ex) {
			System.out.println("Error writing to file " + fileName);
		}
		System.out.println(fileName + " opened\n");
		// printing data to file
		for (int i = 0; i < data.length; i++) {
			outFile.println(data[i]);
		}
		outFile.close();
		System.out.println(fileName + " closed\n");
	}

	// returns index of value in string array
	public static int getIndex(String[] data, int value) {
		for (int i = 0; i < data.length; i++) {
			String iD = getID(data[i]);
			if (Integer.parseInt(iD) == value) {
				return i;
			}
		}
		return -1;
	}

	// returns ID of song or category
	public static String getID(String line) {
		StringTokenizer st = new StringTokenizer(line, ",");
		return st.nextToken();
	}

	// turns text file into array with each line as a new index
	public static String[] textToArray(String fileName) {
		Scanner inFile = null;
		String line = null;
		String[] newArray = {};
		try {
			inFile = new Scanner(new FileInputStream(fileName));
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file " + fileName);
		} catch (IOException ex) {
			System.out.println("Error reading file " + fileName);
		}
		System.out.println(fileName + " opened\n");
		// reads every line in file and adds to an array
		while (inFile.hasNextLine()) {
			newArray = arrayStringPush(inFile.nextLine(), newArray);
		}
		inFile.close();
		System.out.println(fileName + " closed\n");
		return newArray;
	}

	// returns category closest to song
	public static String matchingCategory(String song, String categories[]) {
		StringTokenizer stSong = new StringTokenizer(song, ",");
		int[] songAspects = {};
		int bestDistance = -1;
		int currentDistance = -1;
		int bestCategoryIndex = 0;
		stSong.nextToken(); // removes ID
		try {
			while (stSong.hasMoreTokens()) { // creates array with aspects of song
				songAspects = arrayIntPush(Integer.parseInt(stSong.nextToken()), songAspects);
			}
			if (songAspects.length == 6) { // ensures right amount of aspects
				for (int i = 0; i < categories.length; i++) { // loops through each category
					int[] categoryAspects = {};
					StringTokenizer stCategory = new StringTokenizer(categories[i], ",");
					int currentCategoryID = Integer.parseInt(stCategory.nextToken());
					int bestCategoryID = -1;
					while (stCategory.hasMoreTokens()) { // creates array with aspects of category
						categoryAspects = arrayIntPush(Integer.parseInt(stCategory.nextToken()), categoryAspects);
					}
					if (i == 0) { // setting variable from initial loop
						bestDistance = getDistance(songAspects, categoryAspects);
						currentDistance = bestDistance;
						bestCategoryID = currentCategoryID;
					} else {
						currentDistance = getDistance(songAspects, categoryAspects);
					}
					if (currentDistance < bestDistance) { // checks for lowest distance to category
						bestDistance = currentDistance;
						bestCategoryIndex = i;
					} else if (currentDistance == bestDistance) { // sets lowest category ID if distance is equal
						if (currentCategoryID < bestCategoryID) {
							bestCategoryIndex = i;
						}
					}
				}
				return categories[bestCategoryIndex]; // returns index of matching category
			} else if (songAspects.length < 6) { // dumps lines without right amount of aspects
				errors = arrayStringPush(song, errors, "Not enough aspect values");
			} else if (songAspects.length > 6) {// dumps lines without right amount of aspects
				errors = arrayStringPush(song, errors, "Too many aspect values");
			}
		} catch (NumberFormatException e) { // dumps lines without proper format
			errors = arrayStringPush(song, errors, "Invalid aspect value/or comma in name");
		}
		return null;
	}

	// Returns distance of song to category
	public static int getDistance(int songAspects[], int categoryAspects[]) {
		int distance = 0;
		for (int i = 0; i < 6; i++) {
			distance += Math.pow(categoryAspects[i] - songAspects[i], 2);
		}
		return distance;
	}

	// adds String to end of array
	public static String[] arrayStringPush(String item, String[] oldArray) {
		int len = oldArray.length;
		String[] newArray = new String[len + 1];
		System.arraycopy(oldArray, 0, newArray, 0, len);
		newArray[len] = item;
		return newArray;
	}

	// adds String to end of array with a "message". Used for errors (method
	// overloading)
	public static String[] arrayStringPush(String item, String[] oldArray, String message) {
		int len = oldArray.length;
		String[] newArray = new String[len + 1];
		System.arraycopy(oldArray, 0, newArray, 0, len);
		newArray[len] = item + " (" + message + ")";
		return newArray;
	}

	// adds int to end of array
	public static int[] arrayIntPush(int item, int[] oldArray) {
		int len = oldArray.length;
		int[] newArray = new int[len + 1];
		System.arraycopy(oldArray, 0, newArray, 0, len);
		newArray[len] = item;
		return newArray;
	}

}
