
public class Taxi implements Vehicle {

	// VARIABLES FOR TAXIS
	int stateID;
	int vehicleID;
	int coordinateX;
	int coordinateY;
	boolean inUse;

	// CREATING TAXI
	Taxi(int stateID, int vehicleID, int coordinateX, int coordinateY) {
		setStateID(stateID);
		setVehicleID(vehicleID);
		setCoordinateX(coordinateX);
		setCoordinateX(coordinateY);
		this.inUse = false;
	}

	// SETTERS AND GETTERS
	public boolean isInUse() {
		return inUse;
	}

	public void setInUse(boolean inUse) {
		this.inUse = inUse;
	}

	public int getStateID() {
		return stateID;
	}

	public void setStateID(int stateID) {
		this.stateID = stateID;
	}

	public int getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}

	public int getCoordinateX() {
		return coordinateX;
	}

	public void setCoordinateX(int coordinateX) {
		this.coordinateX = coordinateX;
	}

	public int getCoordinateY() {
		return coordinateY;
	}

	public void setCoordinateY(int coordinateY) {
		this.coordinateY = coordinateY;
	}

}
