
public class Truck implements Vehicle {

	// VARIABLES FOR TRUCKS
	int stateID;
	int vehicleID;
	String destination;
	int maxLoad;
	int currentLoad;
	boolean outForDelivery;

	// CREATING TRUCKS
	Truck(int stateID, int vehicleID, String destination, int maxLoad, int currentLoad) {
		setStateID(stateID);
		setVehicleID(vehicleID);
		setDestination(destination);
		setMaxLoad(maxLoad);
		setCurrentLoad(currentLoad);
		this.outForDelivery = false;
	}

	// SETTERS AND GETTERS
	public int getStateID() {
		return stateID;
	}

	public void setStateID(int stateID) {
		this.stateID = stateID;
	}

	public int getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getMaxLoad() {
		return maxLoad;
	}

	public void setMaxLoad(int maxLoad) {
		if (maxLoad >= currentLoad) { // MAKING SURE NEW MAX CAN HANDLE CURRENT LOAD
			this.maxLoad = maxLoad;
		} else {
			System.out.println("Max Load too low for current load");
		}

	}

	public int getCurrentLoad() {
		return currentLoad;
	}

	public void setCurrentLoad(int currentLoad) {
		if (currentLoad <= this.maxLoad) { // MAKING SURE NEW LOAD IS LESS THAN MAX
			this.currentLoad = currentLoad;
		} else {
			System.out.println("Cant set a load greater than the Max Load");
		}
	}

	public boolean isInUse() {
		return outForDelivery;
	}

	public void setIsInUse(boolean inUse) {
		this.outForDelivery = inUse;
	}

}
