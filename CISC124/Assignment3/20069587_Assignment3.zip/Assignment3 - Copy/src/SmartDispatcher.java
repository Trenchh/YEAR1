import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/*
 * Name: SmartDispatcher.java
 * Due Date: April 1st, 2018
 * Version: v0.1
 * Author: Ryan Protheroe (SN: 20069587) (netID: 17RCP)
 */

public class SmartDispatcher {
	// GLOBAL VARIABLES FOR INPUT/OUTPUT
	public static Scanner inFile = null;
	public static ArrayList<String> busOutput = new ArrayList<String>();
	public static ArrayList<String> truckOutput = new ArrayList<String>();
	public static ArrayList<String> taxiOutput = new ArrayList<String>();

	public static void main(String[] args) {
		// INITIALIZING ARRAYLISTS
		ArrayList<Bus> buses = new ArrayList<Bus>();
		ArrayList<Truck> trucks = new ArrayList<Truck>();
		ArrayList<Taxi> taxis = new ArrayList<Taxi>();
		ArrayList<BusCall> busCalls = new ArrayList<BusCall>();
		ArrayList<TruckCall> truckCalls = new ArrayList<TruckCall>();
		ArrayList<TaxiCall> taxiCalls = new ArrayList<TaxiCall>();
		ArrayList<Integer> fleetSizes = new ArrayList<Integer>();
		ArrayList<Fleet> busFleets = new ArrayList<Fleet>();
		ArrayList<Fleet> truckFleets = new ArrayList<Fleet>();
		ArrayList<Fleet> taxiFleets = new ArrayList<Fleet>();

		// GRABBING INFORMATION FROM .txt FILES
		buses = busReader(inFile, buses);
		busCalls = busCallReader(inFile, busCalls);
		trucks = truckReader(inFile, trucks);
		truckCalls = truckCallReader(inFile, truckCalls);
		taxis = taxiReader(inFile, taxis);
		taxiCalls = taxiCallReader(inFile, taxiCalls);
		fleetSizes = fleetReader(inFile, fleetSizes);

		// CREATING FLEETS
		busFleets = busesToFleets(buses, fleetSizes.get(0));
		truckFleets = trucksToFleets(trucks, fleetSizes.get(1));
		taxiFleets = taxisToFleets(taxis, fleetSizes.get(2));

		// RESOLVING TRANSACTIONS FOR EACH VEHICLE
		for (int i = 0; i < busCalls.size(); i++) {
			busFleets = busTransaction(busFleets, busCalls.get(i));
		}

		for (int i = 1; i < truckCalls.size(); i++) {
			truckFleets = truckTransaction(truckFleets, truckCalls.get(i));
		}

		for (int i = 1; i < taxiCalls.size(); i++) {
			taxiFleets = taxiTransaction(taxiFleets, taxiCalls.get(i));
		}

		// WRITING TO OUTPUT FILES
		selectionOutputFile(busOutput, "BusSelections.txt");
		selectionOutputFile(taxiOutput, "TaxiSelections.txt");
		selectionOutputFile(truckOutput, "TruckSelections.txt");
		ArrayList<Fleet> combinedFleets = new ArrayList<Fleet>();
		combinedFleets = combiningFleetsHelper(busFleets, combinedFleets);
		combinedFleets = combiningFleetsHelper(taxiFleets, combinedFleets);
		combinedFleets = combiningFleetsHelper(truckFleets, combinedFleets);
		finalUsageReportOutput(combinedFleets, "finalUsageReport.txt");

	}

	// METHODS FOR WRITING TO OUTPUT FILES
	// -------------------------------------------------------------------------------------------------------------------

	// OUTPUT FOR FINAL REPORT
	public static void finalUsageReportOutput(ArrayList<Fleet> output, String fileName) {
		PrintWriter outFile = null;
		try {
			outFile = new PrintWriter(new FileOutputStream(fileName));
		} catch (IOException ex) {
			System.out.println("Error writing to file " + fileName);
		}
		ArrayList<String> report = usageReportFormat(output); // GETTING THE OUTPUT USING A HELPER METHOD
		for (int i = 0; i < report.size(); i++) { // LOOPING THROUGH AND PRINTING REPORT TO FILE
			outFile.println(report.get(i));
		}

		outFile.close(); // CLOSING FILE

	}

	// OUTPUT FOR "BusSelection", etc.
	public static void selectionOutputFile(ArrayList<String> output, String fileName) {
		PrintWriter outFile = null;
		try {
			outFile = new PrintWriter(new FileOutputStream(fileName));
		} catch (IOException ex) {
			System.out.println("Error writing to file " + fileName);
		}
		for (int i = 0; i < output.size(); i++) { // LOOPING THROUGH AND PRINTING OUTPUT
			outFile.println(output.get(i));
		}
		outFile.close(); // CLOSING FILE

	}

	// HELPER METHODS
	// ------------------------------------------------------------------------------------------------------------------

	// FORMATS THE FINAL USAGE REPORT
	public static ArrayList<String> usageReportFormat(ArrayList<Fleet> fleets) {
		ArrayList<String> report = new ArrayList<String>();
		for (Fleet fleet : fleets) { // LOOPS THROUGH EACH FLEET TO GRAB INFO AND FORMAT NEATLY
			ArrayList<Vehicle> vehicles = fleet.getVehicles(); // ACQUIRING LIST OF VEHICLES IN FLEET
			int counter = 0;
			for (int i = 0; i < vehicles.size(); i++) { // COUNTER FOR "IN USE" PART OF REPORT
				if (vehicles.get(i).isInUse() == true) {
					counter++;
				}
			}
			report.add("Vehicle Type = " + fleet.getVehicle(0).getClass().getName() + ", State = " + fleet.getStateID()
					+ ", Fleet Size = " + fleet.getVehicles().size() + ", In Use = " + counter); // FORMAT OF REPORT
		}
		return report;
	}

	// CALCULATES THE DISTANCE FROM TAXI TO DESTINATION USING "STRAIGHT LINE" METHOD
	public static int taxiDistance(int taxiX, int taxiY, int destinationX, int destinationY) {
		int x = taxiX - destinationX;
		int y = taxiY - destinationY;
		return (int) Math.sqrt(x * x + y * y);
	}

	// ADDS FLEETS FROM OTHER ARRAYLISTS TO ONE ARRAYLIST
	public static ArrayList<Fleet> combiningFleetsHelper(ArrayList<Fleet> fleets, ArrayList<Fleet> combinedFleet) {
		for (Fleet fleet : fleets) {
			combinedFleet.add(fleet);
		}
		return combinedFleet;
	}

	// RESOLVING TRANSACTIONS
	// -------------------------------------------------------------------------------------------------------------------
	public static ArrayList<Fleet> taxiTransaction(ArrayList<Fleet> taxiFleets, TaxiCall call) {
		ArrayList<Taxi> taxis = taxiFleets.get(call.getStateID() - 1).getVehicles(); // GETTING TAXIS BASED ON STATE ID
		Taxi taxiFound = null;
		ArrayList<Integer> distances = new ArrayList<Integer>(); // USED TO SORT TAXIS
		ArrayList<Taxi> sortedTaxis = new ArrayList<Taxi>(); // SORTED TAXIS LIST
		for (Taxi taxi : taxis) { // GETTING DISTANCE TO DESTINATION FOR ALL TAXIS
			distances.add(taxiDistance(taxi.getCoordinateX(), taxi.getCoordinateY(), call.getCoordinateX(),
					call.getCoordinateY()));

		}
		Collections.sort(distances); // SORTING DISTANCES, (LEAST TO GREATEST)
		for (int distance : distances) { // LOOP THROUGH EACH DISTANCE VALUE TO FIND MATCHING TAXI
			for (Taxi taxi : taxis) { // LOOPING THROUGH TAXIS
				if (taxiDistance(taxi.getCoordinateX(), taxi.getCoordinateY(), call.getCoordinateX(),
						call.getCoordinateY()) == distance) {
					sortedTaxis.add(taxi); // ADDING TAXI TO ARRAY IN SORTED ORDER
				}
			}
		}
		// TAXIS NOW SORTED BY DISTANCE
		int searchCap = 2; // USED FOR ALGORITHM
		int counter = 0; // MAKES SURE WE DONT GET OUT OF BOUNDS ERROR
		int totalSize = sortedTaxis.size(); // GETTING LIST SIZE
		int distanceToDestination = -1;
		while (taxiFound == null && counter < totalSize) { // CONTINUOUS LOOP TO ENSURE A TAXI IS WHEN POSSIBLE
			ArrayList<Taxi> searchGroup = new ArrayList<Taxi>(); // ARRAYLIST OF TAXIS THAT CAN BE RANDOMLY ASSIGNED
			int iterator = 0; // USED TO LOOP THROUGH ELIGIBLE TAXIS
			if (searchCap > sortedTaxis.size()) { // ENSURES NO OUT OF BOUNDS
				searchCap = sortedTaxis.size();
			}
			for (int i = 0; i < searchCap; i++) { // GETTING TAXIS THAT CAN BE RANDOMLY SELECTED
				searchGroup.add(sortedTaxis.get(i));
			}
			while (iterator < searchGroup.size()) { // LOOP TO FIND IF ELIGIBLE TAXIS ARE AVAILABLE
				int random = (int) Math.random() * (searchCap - iterator); // PICKS RANDOM NUMBER
				if (searchGroup.get(random).isInUse() == false) { // CHECKS IF RANDOM TAXI IS AVAILABLE
					taxiFound = searchGroup.get(random); // TAXI FOUND
					distanceToDestination = taxiDistance(taxiFound.getCoordinateX(), taxiFound.getCoordinateY(),
							call.getCoordinateX(), call.getCoordinateY()); // LOGS DISTANCE FOR OUTPUT FILE
					break; // BREAKS LOOP IF FOUND
				}
				searchGroup.remove(random); // REMOVES TAXI FROM SEARCHGROUP IF UNAVAILABLE
				iterator++; // KEEPING TRACK OF TAXIS LEFT TO SEARCH FROM CURRENT GROUP
			}
			for (int i = 0; i < searchCap; i++) { // CLOSEST UNAVAILABLE TAXIS REMOVED FROM SEARCHES
				sortedTaxis.remove(0);
			}
			counter += searchCap; // KEEPS TRACK OF TAXIS SEARCHED IN TOTAL
			searchCap = searchCap * 2; // INCREASING SEARCH GROUP FOR ALGORITHM
		}

		if (taxiFound != null) {
			for (int i = 0; i < taxis.size(); i++) { // FINDING TAXI IN LIST FROM FLEET
				if (taxis.get(i) == taxiFound) {
					taxiFound.setInUse(true); // SETTING TAXI TO BE UNAVAILABLE
					taxis.set(i, taxiFound); // SETTING TAXI TO THE TAXI FOUND
				}
			}
			taxiFleets.get(call.getStateID() - 1).setVehicles(taxis); // UPDATING FLEET WITH IN USE TAXI
			taxiOutput.add(taxiFound.getStateID() + "\t" + taxiFound.getVehicleID() + "\t" + distanceToDestination); // OUTPUT
		} else {
			System.out.println("Unsuccessful taxi search");
			taxiOutput.add("Taxi Call of state " + call.getStateID() + " to coordinates (" + call.getCoordinateX() + ","
					+ call.getCoordinateY() + ") could not be satisfied"); // OUTPUT FOR UNSUCCESFUL SEARCH
		}

		return taxiFleets; // RETURNING UPDATED FLEET

	}

	public static ArrayList<Fleet> truckTransaction(ArrayList<Fleet> truckFleets, TruckCall call) {
		ArrayList<Truck> trucks = truckFleets.get(call.getStateID() - 1).getVehicles(); // TRUCKS WITH MATCHING STATE ID
		Truck truckFound = null;
		int mostSpace = -1;
		for (Truck truck : trucks) { // LOOPING ALL TRUCKS
			if (truck.getDestination().equals(call.getDestination()) && truck.isInUse() == false
					&& (truck.getMaxLoad() - truck.getCurrentLoad()) > call.getMass()) { // FOUND ELIGIBLE TRUCK
				if ((truck.getMaxLoad() - truck.getCurrentLoad()) >= mostSpace) { // FINDING TRUCK WITH MOST SPACE
					mostSpace = truck.getMaxLoad() - truck.getCurrentLoad();
					truckFound = truck;
				}
			}
		}
		if (truckFound != null) {
			truckFound.setCurrentLoad(truckFound.getCurrentLoad() + call.getMass()); // SETTING NEW LOAD
			for (int i = 0; i < trucks.size(); i++) { // FINDING TRUCK FROM ORIGINAL LIST
				if (trucks.get(i) == truckFound) {
					if (truckFound.getCurrentLoad() >= (0.9 * truckFound.getMaxLoad())) {
						truckFound.setIsInUse(true); // SETTING TRUCK TO "IN USE" IF CURRENT LOAD IS >= 90% OF MAXLOAD
					}
					trucks.set(i, truckFound); // RELPLACING OLD WITH NEW TRUCK
				}
			}
			truckFleets.get(call.getStateID() - 1).setVehicles(trucks); // UPDATING FLEET
			truckOutput.add(truckFound.getStateID() + "\t \t" + truckFound.getVehicleID() + "\t \t" + call.getMass()
					+ "\t \t" + (truckFound.getMaxLoad() - (truckFound.getCurrentLoad() - call.getMass())) + "\t \t"
					+ (truckFound.getMaxLoad() - truckFound.getCurrentLoad())); // OUTPUT FOR SUCCESSFUL SEARCH
		} else {
			System.out.println("Unsuccessful truck search");
			truckOutput.add("Truck call of state " + call.getStateID() + " for parcel of mass " + call.getMass()
					+ "kg to " + call.getDestination() + " could not be satisfied"); // OUTPUT FOR UNSUCCESSFUL SEARCH
		}
		return truckFleets; // RETURNING UPDATED FLEET
	}

	public static ArrayList<Fleet> busTransaction(ArrayList<Fleet> busFleets, BusCall call) {
		ArrayList<Bus> eligibleBuses = new ArrayList<Bus>();
		ArrayList<Bus> buses = busFleets.get(call.getStateID() - 1).getVehicles(); // BUSES WITH MATCHING STATE ID
		Bus busFound = null;
		int averageMileage = 0; // FOR FINDING BUS CLOSEST TO AVERAGE MILEAGE
		int seatsRequired = call.getSeats(); // SEATS NEEDED FOR "TRIP"
		for (Bus bus : buses) { // FIND BUSES NOT IN SUE AND HAVE ENOUGH SEATS
			if (bus.getSeatsOnBus() >= seatsRequired && bus.isInUse() == false) {
				eligibleBuses.add(bus); // BUSES WITH ENOUGH SEATS AND NOT IN USE
				averageMileage += (bus.getCurrentMileage()); // TOTALS MILEAGE OF ALL ELIGIBLE BUSES
			}
		}

		if (eligibleBuses.size() != 0) {
			averageMileage = averageMileage / eligibleBuses.size(); // CALCULATES AVERAGE MILEAGE
			int closestMileage = Math.abs(eligibleBuses.get(0).getCurrentMileage() - averageMileage); // INITIAL BUS
			busFound = eligibleBuses.get(0);
			for (Bus bus : eligibleBuses) { // LOOPS THROUGH ELIGIBLE BUSES TO FIND MILEAGE CLOSEST TO AVERAGE
				int currentDifference = Math.abs(eligibleBuses.get(0).getCurrentMileage() - averageMileage);
				if (currentDifference < closestMileage) {
					busFound = bus; // SETS NEW BUS FOUND
				}
			}
			for (int i = 0; i < buses.size(); i++) { // LOOPS THROUGH INITIAL LIST TO FIND PICKED BUS
				if (buses.get(i) == busFound) {
					busFound.setInUse(true); // SETS TO IN USE
					buses.set(i, busFound); // UPDATES BUS
				}
			}
			busFleets.get(call.getStateID() - 1).setVehicles(buses); // UPDATES FLEET
			busOutput.add(busFound.getStateID() + "\t" + busFound.getVehicleID() + "\t" + busFound.getCurrentMileage()
					+ "\t" + busFound.getSeatsOnBus()); // OUTPUT FOR SUCCESSFUL SEARCH
		} else {
			System.out.println("Unsuccessful bus search");
			busOutput.add("Bus call of state " + call.getStateID() + " needing " + call.getSeats() + " seats to "
					+ call.getDestination() + " could not be satisfied"); // OUTPUT FOR UNSUCCESSFUL SEARCH
		}
		return busFleets; // RETURNS UPDATED FLEET
	}

	// CREATING FLEETS OF VEHICLES SORTED BY STATE ID
	// --------------------------------------------------------------------------------------------------------------\

	// TAKES LIST OF BUSES AND PUTS IN FLEETS ORDERED BY STATE ID
	public static ArrayList<Fleet> busesToFleets(ArrayList<Bus> vehicles, int maxFleetSize) {
		int iterator = 0; // USED TO LOOP THROUGH ALL BUSES
		ArrayList<Fleet> fleets = new ArrayList<Fleet>();
		int stateSorter = 1; // SORTS STATES
		while (iterator < vehicles.size()) { // LOOPS THROUGH ALL BUSES
			ArrayList<Bus> buses = new ArrayList<Bus>(); // CREATES NEW LIST
			while (stateSorter == vehicles.get(iterator).getStateID()) { // FINDS BUSES WITH STATESORTER ID
				buses.add(vehicles.get(iterator)); // ADDS BUS TO LIST
				iterator++;
				if (iterator == vehicles.size()) { // ENSURES NO OUT OF BOUNDS
					break;
				}
			}
			Fleet newFleet = new Fleet(stateSorter, buses, maxFleetSize); // CREATES FLEET OF BUSES STATE X
			fleets.add(newFleet); // ADDS NEW FLEET TO LIST OF FLEETS
			stateSorter++; // CHANGES STATE ID
		}
		return fleets; // RETURNS LIST OF ALL FLEETS
	}

	// TAKES LIST OF TRUCKS AND PUTS IN FLEETS ORDERED BY STATE ID
	public static ArrayList<Fleet> trucksToFleets(ArrayList<Truck> vehicles, int maxFleetSize) {
		int iterator = 0;
		ArrayList<Fleet> fleets = new ArrayList<Fleet>();
		int stateSorter = 1;
		while (iterator < vehicles.size()) {
			ArrayList<Truck> trucks = new ArrayList<Truck>();
			while (stateSorter == vehicles.get(iterator).getStateID()) {
				trucks.add(vehicles.get(iterator));
				iterator++;
				if (iterator == vehicles.size()) {
					break;
				}
			}
			Fleet newFleet = new Fleet(stateSorter, trucks, maxFleetSize);
			fleets.add(newFleet);
			stateSorter++;
		}
		return fleets;
	}

	// TAKES LIST OF TAXIS AND PUTS IN FLEETS ORDERED BY STATE ID
	public static ArrayList<Fleet> taxisToFleets(ArrayList<Taxi> vehicles, int maxFleetSize) {
		int iterator = 0;
		ArrayList<Fleet> fleets = new ArrayList<Fleet>();
		int stateSorter = 1;
		while (iterator < vehicles.size()) {
			ArrayList<Taxi> taxis = new ArrayList<Taxi>();
			while (stateSorter == vehicles.get(iterator).getStateID()) {
				taxis.add(vehicles.get(iterator));
				iterator++;
				if (iterator == vehicles.size()) {
					break;
				}
			}
			Fleet newFleet = new Fleet(stateSorter, taxis, maxFleetSize);
			fleets.add(newFleet);
			stateSorter++;
		}
		return fleets;
	}

	// READING FILES AND RETURNING LISTS OF DATA
	// -----------------------------------------------------------------------------------------------------------------------------------

	// GETTING CALLS FOR TAXIS
	public static ArrayList<TaxiCall> taxiCallReader(Scanner inFile, ArrayList<TaxiCall> taxiCalls) {
		try {
			inFile = new Scanner(new FileInputStream("taxiCalls.txt"));
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file taxiCalls.txt");
		} catch (IOException ex) {
			System.out.println("Error reading file taxiCalls.txt");
		}
		while (inFile.hasNextLine()) { // GOING THROUGH FILE
			String[] line;
			line = inFile.nextLine().split("\t");
			TaxiCall newTaxiCall = new TaxiCall(Integer.parseInt(line[0]), Integer.parseInt(line[1]),
					Integer.parseInt(line[2])); // CREATING TAXI CALLL
			taxiCalls.add(newTaxiCall); // ADDING CALL TO LIST
		}
		inFile.close(); // CLOSING FILE
		return taxiCalls; // RETURNING LIST OF CALLS
	}

	// GETTING CALLS FOR TRUCKS
	public static ArrayList<TruckCall> truckCallReader(Scanner inFile, ArrayList<TruckCall> truckCalls) {
		try {
			inFile = new Scanner(new FileInputStream("truckCalls.txt"));
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file truckCalls.txt");
		} catch (IOException ex) {
			System.out.println("Error reading file truckCalls.txt");
		}
		while (inFile.hasNextLine()) {
			String[] line;
			line = inFile.nextLine().split("\t");
			TruckCall newTruckCall = new TruckCall(Integer.parseInt(line[0]), line[1], Integer.parseInt(line[2]));
			truckCalls.add(newTruckCall);
		}
		inFile.close();
		return truckCalls;
	}

	// GETTING CALLS FOR BUSES
	public static ArrayList<BusCall> busCallReader(Scanner inFile, ArrayList<BusCall> busCalls) {
		try {
			inFile = new Scanner(new FileInputStream("busCalls.txt"));
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file busCalls.txt");
		} catch (IOException ex) {
			System.out.println("Error reading file busCalls.txt");
		}
		while (inFile.hasNextLine()) {
			String[] line;
			line = inFile.nextLine().split("\t");
			BusCall newBusCall = new BusCall(Integer.parseInt(line[0]), line[1], Integer.parseInt(line[2]));
			busCalls.add(newBusCall);
		}
		inFile.close();
		return busCalls;
	}

	// READING FLEET SIZES
	public static ArrayList<Integer> fleetReader(Scanner inFile, ArrayList<Integer> fleetSizes) {
		try {
			inFile = new Scanner(new FileInputStream("fleetSizes.txt"));
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file fleetSizes.txt");
		} catch (IOException ex) {
			System.out.println("Error reading file fleetSizes.txt");
		}
		while (inFile.hasNextLine()) {
			String[] line;
			line = inFile.nextLine().split(" ");
			fleetSizes.add(Integer.parseInt(line[1])); // ONLY ADDING VALUE, NOT TEXT
		}
		inFile.close();
		return fleetSizes; // RETURNING SIZES
	}

	// GETTING TAXIS FROM FILE
	public static ArrayList<Taxi> taxiReader(Scanner inFile, ArrayList<Taxi> taxis) {
		try {
			inFile = new Scanner(new FileInputStream("taxiStates.txt"));
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file taxiStates.txt");
		} catch (IOException ex) {
			System.out.println("Error reading file taxiStates.txt");
		}
		while (inFile.hasNextLine()) { // GOING THROUGH FILE
			String[] line;
			line = inFile.nextLine().split("\t");
			Taxi newTaxi = new Taxi(Integer.parseInt(line[0]), Integer.parseInt(line[1]), Integer.parseInt(line[2]),
					Integer.parseInt(line[3])); // CREATING NEW TAXI
			taxis.add(newTaxi); // ADDING TAXI TO LIST
		}
		inFile.close(); // CLOSING FILE
		return taxis; // RETURNING LIST OF TAXIS
	}

	// GETTING TRUCKS FROM FILE
	public static ArrayList<Truck> truckReader(Scanner inFile, ArrayList<Truck> trucks) {
		try {
			inFile = new Scanner(new FileInputStream("truckStates.txt"));
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file truckStates.txt");
		} catch (IOException ex) {
			System.out.println("Error reading file truckStates.txt");
		}
		while (inFile.hasNextLine()) {
			String[] line;
			line = inFile.nextLine().split("\t");
			Truck newTruck = new Truck(Integer.parseInt(line[0]), Integer.parseInt(line[1]), line[2],
					Integer.parseInt(line[3]), Integer.parseInt(line[4]));
			trucks.add(newTruck);
		}
		inFile.close();
		return trucks;
	}

	// GETTING BUSES FROM FILE
	public static ArrayList<Bus> busReader(Scanner inFile, ArrayList<Bus> buses) {
		try {
			inFile = new Scanner(new FileInputStream("busStates.txt"));
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file busStates.txt");
		} catch (IOException ex) {
			System.out.println("Error reading file busStates.txt");
		}
		while (inFile.hasNextLine()) {
			String[] line;
			line = inFile.nextLine().split("\t");
			Bus newBus = new Bus(Integer.parseInt(line[0]), Integer.parseInt(line[1]), Integer.parseInt(line[2]),
					Integer.parseInt(line[3]));
			buses.add(newBus);
		}
		inFile.close();
		return buses;
	}

}
