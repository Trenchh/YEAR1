
public class Bus implements Vehicle {

	// VARIABLES FOR BUSES
	int stateID;
	int vehicleID;
	int currentMileage;
	int seatsOnBus;
	boolean inUse;

	// CREATING BUS
	Bus(int stateID, int vehicleID, int currentMileage, int seatsOnBus) {
		setStateID(stateID);
		setVehicleID(vehicleID);
		setSeatsOnBus(seatsOnBus);
		setCurrentMileage(currentMileage);
		this.inUse = false;
	}

	// SETTERS AND GETTERS
	public int getStateID() {
		return stateID;
	}

	public void setStateID(int stateID) {
		this.stateID = stateID;
	}

	public int getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}

	public int getCurrentMileage() {
		return currentMileage;
	}

	public void setCurrentMileage(int currentMileage) {
		this.currentMileage = currentMileage;
	}

	public int getSeatsOnBus() {
		return seatsOnBus;
	}

	public void setSeatsOnBus(int seatsOnBus) {
		this.seatsOnBus = seatsOnBus;
	}

	public boolean isInUse() {
		return inUse;
	}

	public void setInUse(boolean inUse) {
		this.inUse = inUse;
	}

}
