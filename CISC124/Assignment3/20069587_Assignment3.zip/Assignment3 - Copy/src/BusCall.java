
public class BusCall implements Call {
	// VARIABLES FOR BUS CALLS
	int stateID;
	String destination;
	int seats;

	// CREATING BUS CALLS
	BusCall(int stateID, String destination, int seats) {
		setStateID(stateID);
		setDestination(destination);
		setSeats(seats);
	}

	// SETTERS AND GETTERS
	public int getStateID() {
		return stateID;
	}

	public void setStateID(int stateID) {
		this.stateID = stateID;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}

}
