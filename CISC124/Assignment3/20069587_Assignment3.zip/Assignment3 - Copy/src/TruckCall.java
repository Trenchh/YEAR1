
public class TruckCall implements Call {

	// VARIABLES FOR TRUCK CALLS
	int stateID;
	String destination;
	int mass;

	// CREATING TRUCK CALL
	TruckCall(int stateID, String destination, int mass) {
		setStateID(stateID);
		setDestination(destination);
		setMass(mass);
	}

	// SETTERS AND GETTERS
	public int getStateID() {
		return stateID;
	}

	public void setStateID(int stateID) {
		this.stateID = stateID;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getMass() {
		return mass;
	}

	public void setMass(int mass) {
		this.mass = mass;
	}

}
