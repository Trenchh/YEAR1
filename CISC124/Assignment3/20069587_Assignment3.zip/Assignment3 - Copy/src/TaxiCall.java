
public class TaxiCall implements Call {

	// VARIABLES FOR TAXI CALLS
	int stateID;
	int coordinateX;
	int coordinateY;

	// CREATING TAXI CALLS
	TaxiCall(int stateID, int coordinateX, int coordinateY) {
		setStateID(stateID);
		setCoordinateX(coordinateX);
		setCoordinateX(coordinateY);
	}

	// SETTERS AND GETTERS
	public int getStateID() {
		return stateID;
	}

	public void setStateID(int stateID) {
		this.stateID = stateID;
	}

	public int getCoordinateX() {
		return coordinateX;
	}

	public void setCoordinateX(int coordinateX) {
		this.coordinateX = coordinateX;
	}

	public int getCoordinateY() {
		return coordinateY;
	}

	public void setCoordinateY(int coordinateY) {
		this.coordinateY = coordinateY;
	}

}
