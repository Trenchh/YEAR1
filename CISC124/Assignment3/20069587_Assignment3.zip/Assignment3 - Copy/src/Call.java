//INTERFACE FOR CALLS
public interface Call {
	void setStateID(int newValue);

	int getStateID();

}
