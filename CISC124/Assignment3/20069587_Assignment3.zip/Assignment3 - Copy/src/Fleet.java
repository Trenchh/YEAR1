import java.util.ArrayList;

//GENERIC TYPE
public class Fleet<T> {

	// VARIABLES FOR FLEETS
	int stateID;
	ArrayList<T> vehicles;
	int maxSize;

	// CREATING FLEET
	Fleet(int stateID, ArrayList<T> vehicles, int maxSize) {
		if (vehicles.size() <= maxSize) {
			setStateID(stateID);
			this.maxSize = maxSize;
			setVehicles(vehicles);
		} else { // MAKING SURE MAXSIZE IS GREATER THAN LIST OF VEHICLES
			System.out.println("Fleet size exceeds max size.");
		}
	}

	// SETTERS AND GETTERS
	public int getStateID() {
		return stateID;
	}

	public void setStateID(int stateID) {
		this.stateID = stateID;
	}

	public ArrayList<T> getVehicles() {
		return vehicles;
	}

	public void setVehicles(ArrayList<T> vehicles) {
		if (vehicles.size() <= maxSize) { // MAKING SURE NEW SIZE OF LIST IS LESS THAN MAXSIZE
			this.vehicles = vehicles;
		} else {
			System.out.println("Fleet size can not exceed max size.");

		}

	}

	public int getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(int maxSize) {
		if (maxSize >= vehicles.size()) { // MAKING SURE MAX SIZE ISNT LESS THAN CURRENT SIZE
			this.maxSize = maxSize;
		} else {
			System.out.println("Max Size can not be less than current size.");

		}
	}

	public void addVehicle(T vehicle) {
		if (vehicles.size() < maxSize) { // MAKING SURE NEW VEHICLE DOESNT EXCEED MAX SIZE
			this.vehicles.add(vehicle);
		} else {
			System.out.println("Fleet size at max. Can not add vehicle.");

		}
	}

	public void removeVehicle(T vehicle) {
		this.vehicles.remove(vehicle);
	}

	public T getVehicle(int index) {
		return this.vehicles.get(index);
	}

}
