//INTERFACE FOR VEHICELS
public interface Vehicle {
	void setStateID(int newValue);

	int getStateID();

	void setVehicleID(int newValue);

	boolean isInUse();

}
